// @ts-nocheck
export * from './shared.d.ts';
export { default as Swiper } from './swiper-class.d.ts';
export * from './swiper-events.d.ts';
export * from './swiper-options.d.ts';
export * from './modules/public-api.d.ts';
